
# IncidentQueryResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **createdAt** | **kotlin.String** |  |  [optional] |
| **description** | **kotlin.String** |  |  [optional] |
| **incidentId** | **kotlin.String** |  |  [optional] |
| **latitude** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **longitude** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional] |
| **reporter** | **kotlin.String** |  |  [optional] |
| **type** | **kotlin.String** |  |  [optional] |
| **vote** | **kotlin.Int** |  |  [optional] |



