
# IncidentReportResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **incidentId** | **kotlin.String** |  |  [optional] |



