
# CommonErrorResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **code** | **kotlin.String** |  |  [optional] |
| **message** | **kotlin.String** |  |  [optional] |



